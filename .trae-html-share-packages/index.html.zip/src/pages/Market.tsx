import { useState, useMemo } from "react";
import { SlidersHorizontal, X, TrendingUp, TrendingDown } from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";
import EquipmentCard from "@/components/EquipmentCard";
import {
  equipmentList,
  categoryLabels,
  categoryTree,
  type EquipmentCategory,
  type Condition,
} from "@/data/equipment";
import { priceIndexSeries } from "@/data/priceIndex";
import { cn } from "@/lib/utils";

const categoryOptions: { value: EquipmentCategory | "all"; label: string }[] = [
  { value: "all", label: "全部分类" },
  ...(Object.keys(categoryLabels) as EquipmentCategory[]).map((key) => ({
    value: key,
    label: categoryLabels[key],
  })),
];

const conditionOptions = [
  { value: "all", label: "全部成色" },
  { value: "new", label: "全新" },
  { value: "A", label: "A级" },
  { value: "B", label: "B级" },
  { value: "certified", label: "认证" },
  { value: "preferred", label: "优选" },
];

const sortOptions = [
  { value: "default", label: "默认排序" },
  { value: "price-asc", label: "价格从低到高" },
  { value: "price-desc", label: "价格从高到低" },
  { value: "new", label: "最新上架" },
];

export default function Market() {
  const [category, setCategory] = useState<EquipmentCategory | "all">("all");
  const [subcategory, setSubcategory] = useState<string>("all");
  const [condition, setCondition] = useState<Condition | "all">("all");
  const [brand, setBrand] = useState("全部品牌");
  const [model, setModel] = useState("全部型号");
  const [isNewOnly, setIsNewOnly] = useState(false);
  const [isSelfRun, setIsSelfRun] = useState(false);
  const [priceRange, setPriceRange] = useState(0);
  const [sort, setSort] = useState("default");
  const [showMobileFilter, setShowMobileFilter] = useState(false);

  const handleCategoryChange = (value: EquipmentCategory | "all") => {
    setCategory(value);
    setSubcategory("all");
    setBrand("全部品牌");
    setModel("全部型号");
  };

  const handleSubcategoryChange = (value: string) => {
    setSubcategory(value);
    setBrand("全部品牌");
    setModel("全部型号");
  };

  const handleBrandChange = (value: string) => {
    setBrand(value);
    setModel("全部型号");
  };

  const subcategoryOptions =
    category !== "all" ? categoryTree[category] ?? [] : [];

  // 品牌选项随 品类 / 细分品类 联动
  const brandOptions = useMemo(
    () => [
      "全部品牌",
      ...Array.from(
        new Set(
          equipmentList
            .filter((eq) => category === "all" || eq.category === category)
            .filter(
              (eq) =>
                category === "all" ||
                subcategory === "all" ||
                eq.subcategory === subcategory,
            )
            .map((eq) => eq.brand),
        ),
      ),
    ],
    [category, subcategory],
  );

  // 型号选项随 品类 / 细分品类 / 品牌 联动
  const modelOptions = useMemo(
    () => [
      "全部型号",
      ...Array.from(
        new Set(
          equipmentList
            .filter((eq) => category === "all" || eq.category === category)
            .filter(
              (eq) =>
                category === "all" ||
                subcategory === "all" ||
                eq.subcategory === subcategory,
            )
            .filter((eq) => brand === "全部品牌" || eq.brand === brand)
            .map((eq) => eq.model),
        ),
      ),
    ],
    [category, subcategory, brand],
  );

  const filtered = useMemo(() => {
    let list = equipmentList.filter((eq) => {
      if (category !== "all" && eq.category !== category) return false;
      if (category !== "all" && subcategory !== "all" && eq.subcategory !== subcategory) return false;
      if (condition !== "all" && eq.condition !== condition) return false;
      if (brand !== "全部品牌" && eq.brand !== brand) return false;
      if (model !== "全部型号" && eq.model !== model) return false;
      if (isNewOnly && !eq.isNew) return false;
      if (isSelfRun && !eq.isSelfRun) return false;
      if (priceRange > 0 && eq.price > priceRange) return false;
      return true;
    });

    if (sort === "price-asc") list = [...list].sort((a, b) => a.price - b.price);
    if (sort === "price-desc") list = [...list].sort((a, b) => b.price - a.price);

    return list;
  }, [category, subcategory, condition, brand, model, isNewOnly, isSelfRun, priceRange, sort]);

  const FilterPanel = (
    <div className="space-y-6">
      {/* Category */}
      <div>
        <h3 className="text-xs font-semibold text-ink-900 uppercase tracking-wider mb-3">
          设备品类
        </h3>
        <div className="flex flex-col gap-1.5">
          {categoryOptions.map((opt) => (
            <button
              key={opt.value}
              onClick={() => handleCategoryChange(opt.value)}
              className={cn(
                "text-left px-3 py-1.5 text-sm rounded-md transition-colors",
                category === opt.value
                  ? "bg-brand-50 text-brand-700 font-medium"
                  : "text-ink-600 hover:bg-ink-50"
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Subcategory (contextual) */}
      {subcategoryOptions.length > 0 && (
        <div>
          <h3 className="text-xs font-semibold text-ink-900 uppercase tracking-wider mb-3">
            细分品类
          </h3>
          <div className="flex flex-col gap-1.5">
            <button
              onClick={() => setSubcategory("all")}
              className={cn(
                "text-left px-3 py-1.5 text-sm rounded-md transition-colors",
                subcategory === "all"
                  ? "bg-brand-50 text-brand-700 font-medium"
                  : "text-ink-600 hover:bg-ink-50"
              )}
            >
              全部
            </button>
            {subcategoryOptions.map((opt) => (
              <button
                key={opt.value}
                onClick={() => handleSubcategoryChange(opt.value)}
                className={cn(
                  "text-left px-3 py-1.5 text-sm rounded-md transition-colors",
                  subcategory === opt.value
                    ? "bg-brand-50 text-brand-700 font-medium"
                    : "text-ink-600 hover:bg-ink-50"
                )}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Condition */}
      <div>
        <h3 className="text-xs font-semibold text-ink-900 uppercase tracking-wider mb-3">成色等级</h3>
        <div className="flex flex-wrap gap-1.5">
          {conditionOptions.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setCondition(opt.value as Condition | "all")}
              className={cn(
                "px-2.5 py-1 text-xs rounded-md border transition-colors",
                condition === opt.value
                  ? "border-brand-300 bg-brand-50 text-brand-700"
                  : "border-ink-200 text-ink-600 hover:border-ink-300"
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Brand & model moved to quick filter rows above the toolbar */}

      {/* Price range */}
      <div>
        <h3 className="text-xs font-semibold text-ink-900 uppercase tracking-wider mb-3">
          价格上限
        </h3>
        <input
          type="range"
          min={0}
          max={4000000}
          step={100000}
          value={priceRange}
          onChange={(e) => setPriceRange(Number(e.target.value))}
          className="w-full accent-brand-500"
        />
        <div className="mt-2 flex justify-between text-xs text-ink-500">
          <span>不限</span>
          <span className="font-mono text-brand-600">
            {priceRange === 0 ? "不限" : `¥${priceRange.toLocaleString()}`}
          </span>
        </div>
      </div>

      {/* Toggles */}
      <div className="space-y-2">
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={isNewOnly}
            onChange={(e) => setIsNewOnly(e.target.checked)}
            className="rounded accent-brand-500"
          />
          <span className="text-sm text-ink-700">仅看全新</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={isSelfRun}
            onChange={(e) => setIsSelfRun(e.target.checked)}
            className="rounded accent-brand-500"
          />
          <span className="text-sm text-ink-700">平台自营</span>
        </label>
      </div>
    </div>
  );

  return (
    <div className="bg-white min-h-screen">
      {/* Page header */}
      <div className="relative overflow-hidden bg-gradient-to-br from-brand-50 to-white border-b border-ink-100">
        <div className="absolute inset-0 bg-grid opacity-40" />
        <div className="container relative py-10">
          <div className="flex items-center gap-2 text-xs text-ink-500 mb-2">
            <span>首页</span>
            <span>/</span>
            <span className="text-ink-900">设备交易</span>
          </div>
          <h1 className="text-3xl font-bold text-ink-900">设备交易</h1>
          <p className="mt-2 text-sm text-ink-500">
            一手自营 + 二手认证设备，覆盖 GPU 服务器、CPU 服务器、AI 服务器整机、网络设备、存储设备、供电与散热、机柜与基础设施、集群软件八大品类
          </p>
        </div>
      </div>

      <div className="container py-8">
        <div className="flex gap-8">
          {/* Sidebar - desktop */}
          <aside className="hidden lg:block w-64 shrink-0">
            <div className="sticky top-24 bg-white rounded-xl border border-ink-200 p-5">
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-serif text-base font-bold text-ink-900">筛选条件</h2>
                <SlidersHorizontal className="h-4 w-4 text-ink-400" />
              </div>
              {FilterPanel}
            </div>
          </aside>

          {/* Main */}
          <div className="flex-1 min-w-0">
            {/* Quick filters: brand & model */}
            <div className="mb-5 space-y-2.5">
              {/* Brand row */}
              <div className="flex items-start gap-3">
                <span className="mt-1 w-8 shrink-0 text-xs font-semibold text-ink-900 uppercase tracking-wider">
                  品牌
                </span>
                <div className="flex-1 min-w-0 flex flex-wrap gap-1.5">
                  {brandOptions.map((b) => (
                    <button
                      key={b}
                      onClick={() => handleBrandChange(b)}
                      className={cn(
                        "whitespace-nowrap px-2.5 py-1 text-xs rounded-md border transition-colors",
                        brand === b
                          ? "border-brand-300 bg-brand-50 text-brand-700 font-medium"
                          : "border-ink-200 text-ink-600 hover:border-ink-300"
                      )}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>
              {/* Model row */}
              <div className="flex items-start gap-3">
                <span className="mt-1 w-8 shrink-0 text-xs font-semibold text-ink-900 uppercase tracking-wider">
                  型号
                </span>
                <div className="flex-1 min-w-0 flex flex-wrap gap-1.5">
                  {modelOptions.map((m) => (
                    <button
                      key={m}
                      onClick={() => setModel(m)}
                      className={cn(
                        "whitespace-nowrap px-2.5 py-1 text-xs rounded-md border transition-colors font-mono",
                        model === m
                          ? "border-brand-300 bg-brand-50 text-brand-700 font-medium"
                          : "border-ink-200 text-ink-600 hover:border-ink-300"
                      )}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Toolbar */}
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowMobileFilter(true)}
                  className="lg:hidden inline-flex items-center gap-1.5 px-3 py-2 text-sm border border-ink-200 rounded-md bg-white"
                >
                  <SlidersHorizontal className="h-4 w-4" />
                  筛选
                </button>
                <span className="text-sm text-ink-500">
                  共 <span className="font-mono font-semibold text-ink-900">{filtered.length}</span> 件商品
                </span>
              </div>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="px-3 py-2 text-sm border border-ink-200 rounded-md bg-white focus:outline-none focus:border-brand-400"
              >
                {sortOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Grid */}
            {filtered.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
                {filtered.map((eq) => (
                  <EquipmentCard key={eq.id} equipment={eq} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-ink-200 p-16 text-center">
                <p className="text-sm text-ink-500">没有符合条件的设备，请调整筛选条件</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Price index section */}
      <section className="bg-white border-t border-ink-100">
        <div className="container py-12">
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="h-px w-6 bg-brand-500" />
                <span className="text-xs font-mono uppercase tracking-widest text-brand-600">
                  PRICE INDEX
                </span>
              </div>
              <h2 className="font-serif text-2xl font-bold text-ink-900">设备价格指数</h2>
              <p className="mt-1 text-xs text-ink-500">
                基于平台实际成交数据加权计算，反映设备市场供需变化与价格趋势
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {priceIndexSeries.map((series) => {
              const isUp = series.changePercent >= 0;
              return (
                <div
                  key={series.id}
                  className="p-5 bg-ink-50 rounded-xl hover:bg-white hover:border-brand-300 border border-transparent transition-all"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="text-xs text-ink-500">{series.category}</div>
                      <div className="text-sm font-medium text-ink-900 mt-0.5">{series.model}</div>
                    </div>
                    <div
                      className={cn(
                        "flex items-center gap-0.5 text-xs font-mono px-1.5 py-0.5 rounded",
                        isUp ? "text-rose-600 bg-rose-50" : "text-emerald-600 bg-emerald-50"
                      )}
                    >
                      {isUp ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {isUp ? "+" : ""}{series.changePercent}%
                    </div>
                  </div>
                  <div className="font-mono text-xl font-bold text-ink-900">
                    {series.currentPrice.toLocaleString()}
                    <span className="text-xs text-ink-400 font-sans ml-1">{series.unit}</span>
                  </div>
                  <div className="mt-3 h-12">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={series.trend}>
                        <Line
                          type="monotone"
                          dataKey="price"
                          stroke={isUp ? "#ef4444" : "#10b981"}
                          strokeWidth={1.5}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Mobile filter drawer */}
      {showMobileFilter && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="absolute inset-0 bg-ink-900/50"
            onClick={() => setShowMobileFilter(false)}
          />
          <div className="relative w-80 max-w-[85vw] bg-white h-full overflow-y-auto p-5">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-serif text-base font-bold text-ink-900">筛选条件</h2>
              <button onClick={() => setShowMobileFilter(false)}>
                <X className="h-5 w-5 text-ink-500" />
              </button>
            </div>
            {FilterPanel}
            <button
              onClick={() => setShowMobileFilter(false)}
              className="mt-6 w-full py-2.5 bg-gradient-to-r from-brand-500 to-brand-600 text-white rounded-md font-medium"
            >
              查看 {filtered.length} 件商品
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
